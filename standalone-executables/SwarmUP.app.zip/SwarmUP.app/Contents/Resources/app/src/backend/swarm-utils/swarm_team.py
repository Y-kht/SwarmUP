import threading
import traceback
from collections import Counter
from datetime import datetime

import agent_prompts as prompts
from background_processes import stopProcesses
from harness_utils import SUMMARY_LENGTH, USER_NAME
from loose_json import readReply
from model_adapters import adapterOf


# The end of the text an agent writes now, kept for its card.
LIVE_CHARS = 4000
# The names an agent writes to send a message to every other agent.
BROADCAST_NAMES = ("all", "everyone", "everybody", "team", "all agents")


# The agents of a swarm (Swarm in swarm_harness.py): who joins and who leaves, their models, who waits for whom, and what a user interface reads of them.
# The plan of a leader: {agent: [the agents it waits for]} for each of the workers. A leader often writes one name where a list is asked, or
# null for nobody. KeyError when a worker is not in the plan.
def readWaits(draft, workers):
    plan = readReply(draft)
    return {name: [str(other) for other in ([plan[name]] if isinstance(plan[name], str) else plan[name] or [])] for name in workers}


class SwarmTeam:
    # An agent of the swarm, or one that was just removed and whose thread did not end yet.
    def anyMember(self, name):
        member = self.members.get(name) or self.departed.get(name)
        if member is None:
            raise ValueError(f"There is no agent called {name} in the swarm.")
        return member

    def setStatus(self, name, status):
        self.anyMember(name)["status"] = status
        # An agent that is done or failed changes no file anymore: the files it changed are free for the others (path_guard.py).
        if status in ("done", "failed") and getattr(self, "gateway", None) is not None:
            self.gateway.guard.release(name)
        if name in self.members:
            self.emit("status", name, status=status)

    # boss is the agent this one reports to in the tree (the leader if not given).
    # waitsFor lists the agents whose results this one needs before it can start. It is not used for the leader.
    # model is what getModelInfo gives for the model of the agent. A local model that does not fit in the GPUs is refused.
    # recipe is what the user interface needs to build the agent again after the program stopped (without passwords, they are never saved).
    # While the swarm runs, the new agent joins the group that works now: in plan mode it plans, in execute mode it works and reports to the
    # leader. It can wait for the agents already there (it receives their results), and nobody waits for it. Once the leader started its own
    # final work, nobody can join that run anymore.
    def addAgent(self, name, agent, role, task, boss=None, waitsFor=(), model=None, recipe=None):
        with self.changed:
            if name in self.members or name in self.departed:
                raise ValueError(f"There is already an agent called {name} in the swarm.")
            if name == USER_NAME:
                raise ValueError(f"{USER_NAME} is the name of the user, choose another name for the agent.")
            if boss:
                self.getMember(boss)
            unknown = [other for other in waitsFor if other not in self.members or other == self.leader]
            if unknown:
                raise ValueError(f"{name} cannot wait for {', '.join(unknown)}: they are not agents of the swarm, or it is the leader, who works last.")
            check = self.checkModel(model) if model else {"allowed": True}
            if not check["allowed"]:
                raise ValueError(check["message"])
            stage = self.stage
            if self.active and (stage is None or not stage["open"] or (not stage["plan"] and self.leader in stage["names"])):
                raise ValueError("The leader already started its final work, so no agent can join this run. Add it when the run is over.")
            member = self.newMember(name, agent, role, task, boss, waitsFor, model, recipe)
            self.members[name] = member
            self.leader = self.leader or name
            self.costs.track(name, model, getattr(agent, "agent", None))
            if not self.active:
                return
            self.connectAgent(name, member, False)
            agent.inbox, agent.userMessages, agent.progress, agent.actions = [], [], {}, []
            self.communicate(self.leader, name, self.describe(name))
            # The first agent was alone until now: it gets the tools of the team at its next step.
            if self.gateway is not None:
                for other in self.members:
                    link = self.gateway.find(other)
                    if link is not None:
                        link.stale = True
            self.tellTeam(f"{name} joined the swarm: {role}. Task: {task}" + (f" It waits for {', '.join(waitsFor)}." if waitsFor else ""), exclude=name)
            if not stage["plan"]:
                self.finished[name] = threading.Event()
            self.startInStage(stage, name)
            self.changed.notify_all()
        self.emit("joined", name, role=role)

    def newMember(self, name, agent, role, task, boss, waitsFor, model, recipe):
        return {"name": name, "agent": agent, "role": role, "task": task, "boss": boss, "waitsFor": list(waitsFor), "model": model, "recipe": recipe,
                "status": "waiting", "result": None, "error": "", "mode": self.mode, "review": "", "draft": "", "problem": "",
                "decision": None, "revision": 0, "startAt": None, "started": False, "resumeStart": None, "sitsOut": False, "lost": [], "wake": threading.Event()}

    # Takes an agent out of the swarm (never the leader), while it runs or not. One that finished first gives its result to the agents that wait
    # for it. One that did not finish is stopped at its next step, and the leader decides about the agents that wait for it (swarm_losses.py). Its loop
    # and its model are let go in the background (retire) once its thread ended: what it left half done in the files is put back, and its model frees its memory.
    def removeAgent(self, name, reason=""):
        with self.changed:
            if name == self.leader:
                raise ValueError("The leader cannot be removed: it speaks to you for the swarm.")
            member = self.getMember(name)
            for other in list(self.members.values()):
                if name in other["waitsFor"]:
                    if member["result"] is not None:
                        self.deliverResult(name, other["name"])
                    elif other["mode"] == "plan" or other["status"] not in ("done", "failed"):
                        other["lost"].append({"name": name, "why": reason or member["error"] or "it left the swarm"})
                    other["waitsFor"] = [waited for waited in other["waitsFor"] if waited != name]
            del self.members[name]
            member["removed"] = True
            self.departed[name] = member
            thread = None
            if self.stage is not None and name in self.stage["names"]:
                self.stage["names"].remove(name)
                thread = self.stage["threads"].pop(name)
            if name in self.finished:
                self.finished[name].set()
            member["wake"].set()
            self.removed.append({"name": name, "role": member["role"], "task": member["task"], "status": member["status"],
                                 "result": None if member["result"] is None else str(member["result"])[:SUMMARY_LENGTH], "reason": reason,
                                 "time": f"{datetime.now():%Y-%m-%d %H:%M:%S}"})
            self.changed.notify_all()
        self.tellTeam(f"{name} ({member['role']}) left the swarm. Why: {(reason or 'not given').rstrip('.')}. Do not count on it or wait for it anymore"
                      + (": its result was already given to the agents that needed it." if member["result"] is not None else "."))
        self.emit("removed", name, reason=reason, status=member["status"])
        threading.Thread(target=self.retire, args=(name, member, thread, member["status"] == "done"), daemon=True).start()

    # Every agent of the swarm reads the news of the team with its next prompt (an agent that joined or left), so none of them counts on an
    # agent that left, and all of them know the one that joined.
    def tellTeam(self, news, exclude=None):
        for name, member in list(self.members.items()):
            if name != exclude:
                member["agent"].receive("swarm", news)

    # done is whether the agent had finished when it was removed: what it did after that is put back too.
    # A stop ends what the model of an agent writes now (an API stream, a local model, a turn of a coding agent), in a thread of its own.
    def cancelModel(self, member):
        cancel = getattr(adapterOf(member["agent"].agent), "cancel", None)
        if callable(cancel):
            threading.Thread(target=cancel, daemon=True).start()

    def retire(self, name, member, thread, done):
        self.cancelModel(member)
        if self.gateway is not None:
            self.gateway.cancelLoop(member["agent"])
        if thread is not None:
            thread.join()
        if self.gateway is not None:
            self.gateway.drop(member["agent"])
        stopProcesses(self.id, name)
        try:
            if not done:
                member["agent"].rollback()
            model = member["agent"].agent
            if hasattr(model, "unload"):
                model.unload()
        except Exception:
            traceback.print_exc()
        if self.gateway is not None:
            self.gateway.guard.release(name)
        self.departed.pop(name, None)
        self.emit("retired", name)

    def isRemoved(self, name):
        return name not in self.members and (name in self.departed or any(item["name"] == name for item in self.removed))

    # An agent that did not finish starts again, with what its loop remembers. The ones that finished (done or failed) stay as they are.
    def settle(self, member):
        if member["status"] not in ("done", "failed"):
            member.update(status="waiting", error="", review="", draft="", problem="", decision=None, startAt=None)

    def setLeader(self, name):
        self.getMember(name)
        self.leader = name

    # The mode is used the next time the swarm runs.
    def setMode(self, mode):
        if mode not in ("plan", "execute"):
            raise ValueError("The mode is plan or execute.")
        self.mode = mode

    def getMode(self):
        return self.mode

    # Changes the model of an agent, for example to a smaller one. agent is the new loop that uses it, if the user interface made one.
    # While the swarm runs, only an agent that did not start yet can change its model, and its old model frees its memory.
    def setModel(self, name, model, agent=None):
        with self.changed:
            member = self.getMember(name)
            if self.active and (member["started"] or member["status"] != "waiting"):
                raise ValueError(f"{name} already started, so its model cannot change now. Remove it and add a new agent instead.")
            check = self.checkModel(model, replacing=name)
            if not check["allowed"]:
                raise ValueError(check["message"])
            previous = member["agent"]
            member["model"] = model
            if agent is not None:
                member["agent"] = agent
                self.costs.track(name, model, agent.agent)
                if self.active:
                    # The new loop takes over what the old one already received (the mission, the results of the agents it waited for).
                    agent.inbox, agent.userMessages = list(previous.inbox), list(previous.userMessages)
                    self.connectAgent(name, member, False)
        if self.active and agent is not None and previous.agent is not agent.agent and hasattr(previous.agent, "unload"):
            threading.Thread(target=previous.agent.unload, daemon=True).start()
        if self.active:
            self.emit("model", name, model=model["name"], cli=model.get("cli"))

    # The agents of the swarm for the budget: those that did not finish still set aside the price of 1 million tokens of their model.
    def describeTeam(self):
        return [{"agent": name, "model": member["model"], "client": getattr(member["agent"], "agent", None), "finished": member["status"] in ("done", "failed")}
                for name, member in list(self.members.items())]

    def getCosts(self):
        return self.costs.report(self.describeTeam())

    def setWaitsFor(self, name, waitsFor):
        self.getMember(name)["waitsFor"] = list(waitsFor)

    def getLeader(self):
        return self.leader

    def getAgents(self):
        return list(self.members)

    def getStatuses(self):
        return {name: member["status"] for name, member in self.members.items()}

    # The states the tree shows: an agent whose draft waits for the user is ready, not working.
    def getStates(self):
        return {name: "ready" if member["review"] == "ready" else member["status"] for name, member in list(self.members.items())}

    def getStatus(self, name):
        return self.getMember(name)["status"]

    def getActiveAgents(self):
        return [name for name, status in self.getStatuses().items() if status == "working"]

    def getInactiveAgents(self):
        return [name for name, status in self.getStatuses().items() if status != "working"]

    # The agents with a draft waiting for the user, the ones a user interface shows with a green light.
    def getReadyAgents(self):
        return [name for name, member in self.members.items() if member["review"] == "ready"]

    # The latest summary of the leader, for the user interface to show next to the tree.
    def getSummary(self):
        return self.summary

    def getRole(self, name):
        return self.getMember(name)["role"]

    def getTask(self, name):
        return self.getMember(name)["task"]

    def getParent(self, name):
        member = self.getMember(name)
        return None if name == self.leader else (member["boss"] or self.leader)

    def getChildren(self, name):
        return [other for other in self.members if self.getParent(other) == name]

    # The agents this one is waiting for right now. The leader works last, so it waits for all the others.
    # In plan mode nobody waits for anybody.
    def getWaitingOn(self, name):
        member = self.getMember(name)
        if member["status"] != "waiting" or member["mode"] == "plan":
            return []
        others = [other for other in self.members if other != self.leader] if name == self.leader else member["waitsFor"]
        return [other for other in others if self.members[other]["status"] not in ("done", "failed")]

    def getStartAt(self, name):
        start = self.getMember(name)["startAt"]
        return f"{start:%Y-%m-%d %H:%M}" if start else ""

    # ---------- What an agent reaches of its swarm with its tools (the team server, server_team.py). ----------
    # The name of an agent of the swarm as it was written by another agent: without capitals, and "leader" for the leader.
    def findName(self, written):
        written = str(written).strip().lstrip("@")
        if written.lower() in ("leader", "the leader"):
            return self.leader
        return next((name for name in list(self.members) if name.lower() == written.lower()), None)

    # An agent writes to another one (or to the leader, or to all of them), which reads it with its next step. It gives back what the agent is told.
    def relay(self, sender, receiver, text):
        target, text = self.findName(receiver), str(text).strip()
        if not text:
            raise ValueError("The message is empty.")
        if target is None and str(receiver).strip().lower() in BROADCAST_NAMES:
            return self.broadcast(sender, text)
        if target is None:
            gone = any(item["name"].lower() == str(receiver).strip().lower() for item in self.removed)
            raise ValueError(f"{receiver} left the swarm." if gone else f"There is no agent called {receiver}. The agents: {', '.join(self.members)}.")
        if target == sender:
            raise ValueError("You cannot write to yourself: use memory__keep_note to keep a note.")
        if self.members[target]["status"] in ("done", "failed"):
            return f"{target} has finished, so it cannot read messages anymore. Read its result with team__read_result."
        self.members[target]["agent"].receive(sender, text)
        self.logMessage(sender, target, text, direct=True)
        return f"Sent to {target}. It reads it with its next step."

    # One message to every agent that can still read it (in a real run, an agent sent the same message nine times, once to each).
    def broadcast(self, sender, text):
        readers = [name for name, member in list(self.members.items()) if name != sender and member["status"] not in ("done", "failed")]
        for name in readers:
            self.members[name]["agent"].receive(sender, text)
            self.logMessage(sender, name, text, direct=True)
        finished = [name for name in self.members if name != sender and name not in readers]
        return (f"Sent to {', '.join(readers)}. They read it with their next step." if readers else "Nobody can read it: every other agent has finished.") + \
            (f" {', '.join(finished)} finished, so they cannot read it." if finished and readers else "")

    def describeTeamFor(self, name):
        if len(self.members) == 1 and name in self.members and not self.removed:
            return f"You are {name}, and you work alone: there is no other agent in this swarm.{self.describeWheelsOf(name)}"
        lines = [f"You are {name}. The leader is {self.leader}: it works last, and receives the result of every agent."]
        for other, member in list(self.members.items()):
            waits = f" It waits for {', '.join(member['waitsFor'])}." if member["waitsFor"] and other != self.leader else ""
            ready = " Its result is ready (team__read_result)." if member["result"] is not None and other != name else ""
            lines.append(f"- {other}{' (leader)' if other == self.leader else ''}{' (you)' if other == name else ''}: the {member['role']}, {member['status']}. "
                         f"Task: {member['task']}{waits}{ready}{self.describeWheelsOf(other)}")
        lines += [f"- {item['name']} left the swarm." for item in self.removed]
        return "\n".join(lines)

    # The wheels an agent has, so the leader gives a part of the work that a wheel does to the agent that has it.
    def describeWheelsOf(self, name):
        wheels = getattr(self.members[name]["agent"], "wheels", None) if name in self.members else None
        return f" Its wheels: {', '.join(wheels)}." if wheels else ""

    def resultOf(self, written):
        target = self.findName(written)
        if target is None:
            left = next((item for item in reversed(self.removed) if item["name"].lower() == str(written).strip().lower()), None)
            if left and left["result"] is not None:
                return f"The result of {left['name']}, which left the swarm:\n{left['result']}"
            raise ValueError(f"There is no agent called {written}. The agents: {', '.join(self.members)}.")
        member = self.members[target]
        if member["result"] is None:
            return f"{target} has no result yet: it is {member['status']}." + (f" {member['error']}" if member["error"] else "")
        return f"The result of {target}:\n{member['result']}"

    # An agent that was removed, or a swarm that was stopped, stops at its next step.
    def shouldStop(self, name):
        return self.stopped or self.isRemoved(name)

    def noteActivity(self, name, text):
        self.emit("activity", name, text=text)

    # The text an agent writes now: its card shows it while it writes, and it is gone once the answer is complete.
    def noteText(self, name, text, done=False):
        member = self.members.get(name)
        if member is None:
            return
        member["live"] = "" if done else text[-LIVE_CHARS:]
        self.emit("text", name, text=member["live"], done=done)

    def getInfo(self, name):
        member = self.getMember(name)
        return {"name": name, "role": member["role"], "task": member["task"], "status": member["status"], "boss": self.getParent(name),
                "waitsFor": member["waitsFor"], "waitingOn": self.getWaitingOn(name), "startAt": self.getStartAt(name), "isLeader": name == self.leader,
                "result": member["result"], "error": member["error"], "model": member["model"], "mode": member["mode"], "review": member["review"],
                "draft": member["draft"], "problem": member["problem"], "revision": member["revision"], "plan": member["agent"].approvedPlan,
                "actions": list(member["agent"].actions), "activity": list(member["agent"].activity), "sitsOut": bool(member.get("sitsOut")),
                "live": member.get("live", "")}

    # Who lost the connection and why ({agent: reason}) while the swarm waits for the user to continue or to cancel, otherwise None.
    def getInterruption(self):
        return dict(self.interruption["agents"]) if self.interruption else None

    # The whole swarm as nested dictionaries, starting from the leader, ready to be drawn as a tree.
    def getTree(self, name=None):
        if not self.members:
            return {}
        name = name or self.leader
        member = self.getMember(name)
        return {"name": name, "role": member["role"], "task": member["task"], "status": member["status"], "review": member["review"], "model": member["model"],
                "waitsFor": [] if name == self.leader else member["waitsFor"], "waitingOn": self.getWaitingOn(name), "startAt": self.getStartAt(name),
                "children": [self.getTree(child) for child in self.getChildren(name)]}

    def getMessages(self, sender=None, receiver=None):
        return [message for message in self.messages if sender in (None, message["sender"]) and receiver in (None, message["receiver"])]

    # Who talks to whom and how many messages were sent, for drawing the arrows between the agents.
    def getConnections(self):
        counts = Counter((message["sender"], message["receiver"]) for message in self.messages if message["sender"] != USER_NAME)
        return [{"from": sender, "to": receiver, "count": count} for (sender, receiver), count in counts.items()]

    # waits is {agent: [agents it waits for]}. Returns the groups of agents that work at the same time, one group after the other.
    def findStages(self, waits):
        stages, done = [], set()
        while len(done) < len(waits):
            stage = [name for name in waits if name not in done and all(other in done for other in waits[name])]
            if not stage:
                raise ValueError(f"These agents wait for each other in a circle, so none of them can start: {[name for name in waits if name not in done]}")
            stages.append(stage)
            done.update(stage)
        return stages

    # The agents (without the leader, who works last) that can work at the same time, group after group.
    def getStages(self):
        if not self.members:
            raise ValueError("The swarm has no agents.")
        waits = {name: member["waitsFor"] for name, member in self.members.items() if name != self.leader}
        for name, others in waits.items():
            for other in others:
                if other not in waits:
                    raise ValueError(f"{name} cannot wait for {other}. It is not an agent of the swarm, or it is the leader, who works last.")
        return self.findStages(waits)

    def checkPlan(self, draft):
        workers = [name for name in self.members if name != self.leader]
        try:
            waits = readWaits(draft, workers)
        except (ValueError, KeyError, TypeError):
            return f"Reply only with JSON like {prompts.SWARM_PLAN_EXAMPLE}, with one entry for each of these agents: {workers}"
        unknown = [other for others in waits.values() for other in others if other not in workers]
        if unknown:
            return f"These are not agents you can wait for: {unknown}. Choose from {workers}"
        try:
            self.findStages(waits)
        except ValueError as error:
            return str(error)
        return ""

    # The leader decides who waits for whom, and the user approves its plan like any other draft.
    def planWithLeader(self):
        leader = self.getMember(self.leader)["agent"]
        agents = "\n".join(f"- {name}: {member['role']}. Task: {member['task']}" for name, member in self.members.items() if name != self.leader)
        leader.journal = self.buildLog
        try:
            plan = leader.reviewLoop(prompts.SWARM_PLAN_PROMPT.format(mission=self.mission, agents=agents, example=prompts.SWARM_PLAN_EXAMPLE), self.checkPlan, own=False)
        finally:
            leader.journal = None
        if plan is None:
            return False
        for name, others in readWaits(plan, [name for name in self.members if name != self.leader]).items():
            self.setWaitsFor(name, others)
        return True

    # The picture of the swarm that an agent receives: the mission, its own role and task, and who else is in the swarm.
    def describe(self, name):
        member = self.getMember(name)
        team = "\n".join(f"- {other}{' (leader)' if other == self.leader else ''}: {info['role']}. Task: {info['task']}"
                         f"{' Waits for: ' + ', '.join(info['waitsFor']) + '.' if info['waitsFor'] and other != self.leader else ''}"
                         for other, info in self.members.items())
        alone = "You work alone: there is no other agent in this swarm." if len(self.members) == 1 else f"The agents of the swarm:\n{team}"
        return f"Mission of the swarm: {self.mission}\nYou are {name}, the {member['role']}. Your task: {member['task']}\n{alone}"
